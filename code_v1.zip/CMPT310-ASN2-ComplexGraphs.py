import sys
import timeit

class ColourVertex:
    def __init__(self, name):
        self.name = name
        self.edges = list()
        self.colour = -1
        self.degree = 0
        self.adjacentVertices = list()
        self.legalColoursRemaining = []
        self.numLegalColoursRemaining = 0
    def __str__(self):
        return self.name

class ColourEdge:
    def __init__(self, vertex1, vertex2):
        self.vertex1 = vertex1
        self.vertex2 = vertex2
    def __str__(self):
        return "[" + self.vertex1 + ", " + self.vertex2 + "]"

class ColourGraph:
    def __init__(self, vertices, edges, numColours):
        self.vertices = vertices
        self.edges = edges
        self.numColours = numColours
    def __str__(self):
        return "Edges: " + self.edges

def parseComplexGraphFile(fileName, colourCount):
    vertices = []
    edges = []
    smallest = -1
    largest = -1

    with open(fileName) as f:
        content = f.readlines()
        currentVertex = -1
        for line in content:
            edgeData = [int(s) for s in line.split() if s.isdigit()]
            if len(edgeData) == 2:
                if smallest == -1:
                    smallest = edgeData[0]
                if largest == -1:
                    largest = edgeData[0]
                if edgeData[0] > largest:
                    largest = edgeData[0]
                if edgeData[1] > largest:
                    largest = edgeData[1]

        for i in range(largest):
            vertex = ColourVertex(i+1)
            vertices.append(vertex)
        for line in content:
            edgeData = [int(s) for s in line.split() if s.isdigit()]
            if len(edgeData) == 2:
                if currentVertex == -1:
                    currentVertex = edgeData[0]
                if edgeData[0] != currentVertex:
                    currentVertex = edgeData[0]
                secondaryVertex = edgeData[1]
                edge = ColourEdge(vertices[currentVertex - 1], vertices[secondaryVertex - 1])
                vertices[currentVertex - 1].degree += 1
                vertices[currentVertex - 1].adjacentVertices.append(vertices[secondaryVertex - 1])
                edges.append(edge)
    for vertex in vertices:
        for i in range(colourCount):
            vertex.legalColoursRemaining.append(i)
        vertex.numLegalColoursRemaining = colourCount
    return ColourGraph(vertices, edges, colourCount)

def BacktrackingSearch(graph, useMRVandDegreeHeuristics=False, useLeastConstrainingValueHeuristic=False):
    assignedColours = []
    return RecursiveBacktrack(graph, assignedColours, useMRVandDegreeHeuristics, useLeastConstrainingValueHeuristic)

def RecursiveBacktrack(graph, assignedColours, useMRVandDegreeHeuristics=False, useLeastConstrainingValueHeuristic=False):
    validColouring = True
    if len(assignedColours) == len(graph.vertices):
        for vertex in assignedColours:
            for adjacentVertex in vertex.adjacentVertices:
                if adjacentVertex.colour == vertex.colour:
                    validColouring = False
    else:
        validColouring = False

    if validColouring:
        return assignedColours
    else:
        colours = []
        for colour in range(graph.numColours):
            colours.append(colour)

        if useMRVandDegreeHeuristics:
            unAssignedVertices = getUnassignedVariables(graph, assignedColours)
            vertex = findMinimumRemainingValues(colours, unAssignedVertices)
        else:
            vertex = getUnassignedVariable(graph, assignedColours)
        if vertex is not None:
            if useLeastConstrainingValueHeuristic:
                leastConstrainingColours = findLeastConstrainingValues(vertex, colours)
                for colour in leastConstrainingColours:
                    unusedColour = True
                    for adjacentVertex in vertex.adjacentVertices:
                        if colour == adjacentVertex.colour:
                            unusedColour = False
                    if unusedColour:
                        vertex.colour = colour
                        for tempVertex in vertex.adjacentVertices:
                            if colour in tempVertex.legalColoursRemaining:
                                tempVertex.legalColoursRemaining.remove(colour)
                                tempVertex.numLegalColoursRemaining -= 1
                        assignedColours.append(vertex)
                        result = RecursiveBacktrack(graph, assignedColours, useMRVandDegreeHeuristics, useLeastConstrainingValueHeuristic)
                        if result is not None:
                            return result
                        else:
                            assignedColours.remove(vertex)
                            for tempVertex in vertex.adjacentVertices:
                                if colour not in tempVertex.legalColoursRemaining:
                                    tempVertex.legalColoursRemaining.append(colour)
                                    tempVertex.numLegalColoursRemaining += 1
                            vertex.colour = -1

            else:
                for colour in colours:
                    unusedColour = True
                    for adjacentVertex in vertex.adjacentVertices:
                        if colour == adjacentVertex.colour:
                            unusedColour = False
                    if unusedColour:
                        vertex.colour = colour
                        assignedColours.append(vertex)
                        result = RecursiveBacktrack(graph, assignedColours, useMRVandDegreeHeuristics, useLeastConstrainingValueHeuristic)
                        if result is not None:
                            return result
                        else:
                            assignedColours.remove(vertex)
                            vertex.colour = -1
    return None

def findMinimumRemainingValues(colours, unAssignedVertices):
    minVertex = None
    minVertexColours = len(colours)
    minVertexDegree = 0
    for vertex in unAssignedVertices:
        if minVertex is None:
            minVertex = vertex
            adjacentColours = []
            for adjacentVertex in vertex.adjacentVertices:
                if adjacentVertex.colour not in adjacentColours and adjacentVertex.colour != -1:
                    adjacentColours.append(adjacentVertex.colour)
            minVertexColours = len(colours) - len(adjacentColours)
            minVertexDegree = minVertex.degree
        else:
            adjacentColours = []
            for adjacentVertex in vertex.adjacentVertices:
                if adjacentVertex.colour not in adjacentColours and adjacentVertex.colour != -1:
                    adjacentColours.append(adjacentVertex.colour)
            tempVertexColours = len(colours) - len(adjacentColours)
            tempVertexDegree = minVertex.degree
            if tempVertexColours < minVertexColours:
                minVertexColours = tempVertexColours
                minVertex = vertex
                minVertexDegree = tempVertexDegree
            elif tempVertexColours == minVertexColours and tempVertexDegree > minVertexDegree:
                minVertexColours = tempVertexColours
                minVertex = vertex
                minVertexDegree = tempVertexDegree

    return minVertex

def findLeastConstrainingValues(vertex, colours):
    bestColours = [0 for colour in colours]

    for colour in vertex.legalColoursRemaining:
        for adjacentVertex in vertex.adjacentVertices:
            if adjacentVertex.colour == -1:
                if colour in adjacentVertex.legalColoursRemaining:
                    bestColours[colour] += (adjacentVertex.numLegalColoursRemaining - 1)
                else:
                    bestColours[colour] += adjacentVertex.numLegalColoursRemaining

    leastConstrainingColours = []
    consumedColours = []
    while len(consumedColours) < vertex.numLegalColoursRemaining:
        leastConstrainingColourSum = -1
        leastConstrainingColour = -1
        for colour in vertex.legalColoursRemaining:
            if colour not in consumedColours and bestColours[colour] > leastConstrainingColourSum:
                leastConstrainingColourSum = bestColours[colour]
                leastConstrainingColour = colour
        if leastConstrainingColour != -1:
            leastConstrainingColours.append(leastConstrainingColour)
            consumedColours.append(leastConstrainingColour)
    return leastConstrainingColours

def getUnassignedVariable(graph, assignedColours):
    for vertex in graph.vertices:
        found = False
        for assignment in assignedColours:
            if assignment.name == vertex.name:
                found = True
        if not found:
            return vertex

def getUnassignedVariables(graph, assignedColours):
    vertices = []
    for vertex in graph.vertices:
        found = False
        for assignment in assignedColours:
            if assignment.name == vertex.name:
                found = True
        if not found:
            vertices.append(vertex)
    return vertices

def mainArgs():
    fileName = None
    if len(sys.argv) >= 3:
        fileName = sys.argv[1]
        colourCount = int(sys.argv[2])
    else:
        print "Usage:"
        print "python CMPT310-ASN2-ComplexGraphs.py <complex graph fileName> <numColours> <optional: use MRV heuristic; \'true\'/\'false\'> <optional: use LCV heuristic; \'true\'/\'false\'>"

    if len(sys.argv) == 4:
        useMRV = sys.argv[3] == 'true'
        useLCV = True
    elif len(sys.argv) == 5:
        useMRV = sys.argv[3] == 'true'
        useLCV = sys.argv[4] == 'true'
    else:
        useMRV = True
        useLCV = True

    if fileName is not None:
        graph = parseComplexGraphFile(fileName, colourCount)
        startTime = timeit.default_timer()
        result = BacktrackingSearch(graph, useMRV, useLCV)
        endTime = timeit.default_timer()
        sResult = sorted(result, key=lambda x: x.name)
        print "Execution Time:", (endTime - startTime)
        if result is None:
            print "Failed"
        else:
            for vertex in sResult:
                print "Vertex: %d Colour: %d" % (vertex.name + 1, vertex.colour)

mainArgs()